# LEADS

Label oriented graph Embedding for Anomaly Detection in a Streamof directed labeled edges belonging to heterogeneous graphs.

datasets are available on : 
https://drive.google.com/drive/folders/11a41XWiiSKUS8PucxmbkKqeLypKwJPX_?usp=sharing