#!/usr/bin/env python

SEED = 30
NUM_TRIALS = 30
NUM_DEVS = 3.
