
#ifndef NAADSG_PARAM_H_
#define NAADSG_PARAM_H_

#ifdef DEBUG
#define NDEBUG            0
#endif

extern long M;

//#define  M              25
#define SEED              23
#define INF		   5000000

#endif
